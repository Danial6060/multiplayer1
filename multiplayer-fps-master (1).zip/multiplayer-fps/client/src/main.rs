// Unused default binary removed. This file is intentionally left minimal.
fn main() {}
