//! Minimap rendering stubs. Replace with real maze visualization.

#[allow(dead_code)]
pub fn draw_minimap(buffer: &mut [u32], width: usize, height: usize) {
    // Draw into buffer using your own encoding (ARGB 0xRRGGBB).
    // The window client currently draws a simple grid and a center dot elsewhere.
    let _ = (buffer, width, height);
}
