This folder is currently unused. You can delete `client/assets/` safely.
