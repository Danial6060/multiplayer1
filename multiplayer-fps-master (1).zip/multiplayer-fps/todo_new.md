Pending tasks 

- Client and Server UDP connection 
- Implement client UI (mini-map, Maze-Wars style graphics, FPS counter)
- Implement level progression and round management
- Implement tests and performance validation
- Docs, README and run instructions
- CI / build verification

